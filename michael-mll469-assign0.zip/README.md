Michael -- mll469

Instructions:

Run python whitener.py for the first section.
Run toy_nn.py for the second section.

They both should output graphs with the comparative charts on it. 

There's a pipfile to install some core packages if needed. If anything doesn't work or there are questions, please first email mll469@nyu.edu (my email). Thank you for taking time to grade. 
